<footer class="footer">
    <div class="container text-center"><span class="text-muted"><b>Copyright&copy;Planet Shopify | All Rights Reserved | Contact Us: +91 90000 00000</b></span></div>
</footer>
    